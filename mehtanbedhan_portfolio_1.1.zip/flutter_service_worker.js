'use strict';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "41f3193de61e2ecb8d068e6ef9710ac2",
"assets/assets/parralax_bg/parralax_bg_1.png": "fcd640ec45b07d207a11e98d88451015",
"assets/assets/parralax_bg/parralax_bg_2.png": "3d6f04f0cab91d1ae76ad115b19c8958",
"assets/assets/parralax_bg/parralax_bg_3.png": "664c502ed766b4594c062444a0e79447",
"assets/assets/splashIcon.png": "e536e2f5c1af29fa87fb5525859b4a46",
"assets/FontManifest.json": "01700ba55b08a6141f33e168c4a6c22f",
"assets/fonts/MaterialIcons-Regular.ttf": "56d3ffdef7a25659eab6a68a3fbfaf16",
"assets/LICENSE": "ed2c8b2b11c5eac1bf456ca3d475f560",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "115e937bb829a890521f72d2e664b632",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"index.html": "778a68a616a9cddf7a0d9e6583ab163a",
"/": "778a68a616a9cddf7a0d9e6583ab163a",
"main.dart.js": "60e19984ffc6e3185c02152f1d2f1313",
"manifest.json": "ae1614c04dd2a37d15dd38f571b796b2",
"mehtabedhan_portfolio_1.0.zip": "57270820c2e09629add753616fee124f"
};

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (cacheName) {
      return caches.delete(cacheName);
    }).then(function (_) {
      return caches.open(CACHE_NAME);
    }).then(function (cache) {
      return cache.addAll(Object.keys(RESOURCES));
    })
  );
});

self.addEventListener('fetch', function (event) {
  event.respondWith(
    caches.match(event.request)
      .then(function (response) {
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
  );
});
